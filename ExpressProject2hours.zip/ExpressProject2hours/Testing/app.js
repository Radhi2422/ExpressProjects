const app=require('express')();
const http=require('http').Server(app);

const mongoose=require('mongoose');
mongoose.connect("mongodb+srv://radhika:radhs123@discussion-forum-app.txam8uq.mongodb.net/?retryWrites=true&w=majority")

const userSchema=require('../module/userModel.js')

http.listen(3000,function(){
    console.log("Server is running")
})