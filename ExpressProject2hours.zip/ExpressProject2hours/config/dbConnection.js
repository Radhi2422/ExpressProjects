const mongoose=require("mongoose");
const connectDb=async()=>{
try{
    const connect=await mongoose.connect("mongodb+srv://radhika:radhs123@discussion-forum-app.txam8uq.mongodb.net/ExpressLearn?retryWrites=true&w=majority");
    console.log("Databse connected",connect.connection.host,connect.connection.name);
    
}catch(err){
    console.log(err);
    process.exit(1);
}
}
module.exports=connectDb;