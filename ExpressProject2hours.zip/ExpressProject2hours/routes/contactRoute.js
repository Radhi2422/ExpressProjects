const express=require("express")
const router=express.Router();
const {getContacts,getContact,createContact,updateContact,deleteContact}=require("../controllers/contactController");

router.route('/').get(getContacts).post(createContact);
router.route('/:id').get(getContact).put(updateContact).delete(deleteContact);
// router.route('/:id');
// // router.route('/');
// router.route('/:id');

module.exports=router;